﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PPS.API.Common.Security
{
	public enum AuthorizationProtocol
	{
		None = 0,
		OAuth1A = 1,
		OAuth2 = 2,
	}
}
