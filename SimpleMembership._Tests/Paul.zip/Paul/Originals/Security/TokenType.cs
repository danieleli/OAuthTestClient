﻿
namespace PPS.API.Common.Security
{
	public enum TokenType
	{
		Request = 0,
		Access = 1
	}
}
