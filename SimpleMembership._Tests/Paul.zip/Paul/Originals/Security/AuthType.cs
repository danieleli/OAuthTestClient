﻿
namespace PPS.API.Common.Security
{
	public enum AuthType
	{
		Application = 0,
		User = 1
	}
}
