﻿
using System;
namespace PPS.API.Common.Security
{
    [Serializable]
    public enum ConsumerType
    {
        User = 0,
        Application = 1,
    }
}
