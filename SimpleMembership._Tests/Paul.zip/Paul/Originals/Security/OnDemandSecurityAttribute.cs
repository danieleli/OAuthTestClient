﻿using System;

namespace PPS.API.Common.Security
{
	public class OnDemandSecurityAttribute : Attribute { }

}